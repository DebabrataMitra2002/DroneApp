# Entry point for the drone safety landing app

if __name__ == '__main__':
    print('Starting Drone Safety Landing App...')
