#!/bin/bash
# Script to build AppImage

APP=drone_safety_landing_app
mkdir -p $APP.AppDir
# Copy your files into AppDir and use appimagetool
